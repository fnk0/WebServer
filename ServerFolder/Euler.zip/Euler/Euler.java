import java.util.*;

public class Euler {
	public static void main(String args[]) {

		/*
		boolean myBool = isPrime(80);

		if(myBool == true) {
			System.out.println("TRUE!");
		} else {
			System.out.println("FALSE!");
		}
		*/

		//System.out.println(findLargestFactor(13195));
        //System.out.println(findLargestFactor(600851475143L));

        //largestPalindrome();

        //smallestMultiple();

        sumSquareDifference();
	}

	public static void fibonacci() {

		ArrayList<Integer> nums = new ArrayList<Integer>();
		
		int temp = 0;
		int total = 2;
		int count = 2;
		nums.add(1);
		nums.add(2);
		while(temp < 4000000) {

			temp = nums.get(count - 1) + nums.get(count -2);
			nums.add(temp);

			if(temp % 2 == 0) {
				total += temp;
			}
			count++;

		}

		System.out.println(total);
	}

	public static boolean isPrime(int num) {

		boolean myBool = true;
		for(int i = 2; i < num; i++) {

			if(num % i == 0) {
				myBool = false;
				break;
			} 

		}

		return myBool;
	}

	public static int findLargestFactor(long num) {

		int i;

		for(i = 2; i <= num; i++) {
			if(num % i == 0) {
				num /= i;
				i--;
			}
		}

		return i;
	}

	public static void largestPalindrome() {

		int number = 9801;
		// String number = "998001";
		String reversed = "";
		String counting = "";

		

		for(int i = 0; i <= number; i++) {

			counting = "" + i;
			reversed = new StringBuilder(counting).reverse().toString();
			
			if(counting.equals(reversed)) {
				System.out.println(counting + " is the palindrome of " + reversed);
			}

		}
	}

	public static void smallestMultiple() {

		for(int i = 190; ; i += 190) {
	        if(i % 3 == 0 
	                && i % 4 == 0
	                && i % 6 == 0 
	                && i % 7 == 0
	                && i % 8 == 0 
	                && i % 9 == 0
	                && i % 11 == 0
	                && i % 12 == 0 
	                && i % 13 == 0 
	                && i % 14 == 0 
	                && i % 15 == 0
	                && i % 16 == 0
	                && i % 17 == 0
	                && i % 18 == 0
	                && i % 20 == 0) {
	            System.out.println(i);
	            break;
	        }
   		 }
	}

	public static void sumSquareDifference() {

		int[] array = new int[100];
		int temp = 0;
		int temp2 = 0;
		for(int i = 0; i < 100; i++) {

			array[i] = i + 1;
		}

		for(int i = 0; i < array.length; i++) {

			temp += powerSquare(array[i]);
		}

		for(int i = 0; i < array.length; i++) {

			temp2 += array[i];

		}

		temp2 = powerSquare(temp2);
		temp2 -= temp;

		System.out.println(temp2);

	}

	public static int powerSquare(int a) {

		int b = a * a;
		return b;
	}

}